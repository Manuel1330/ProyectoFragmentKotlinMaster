package com.example.proyectofragmentkotlin

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_div.*
import kotlinx.android.synthetic.main.fragment_multi.*
import kotlinx.android.synthetic.main.fragment_suma.*

class DivFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_div, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            val resultado = DivFragmentArgs.fromBundle(it).resultadoDiv
            val num1Mostrar = DivFragmentArgs.fromBundle(it).num1Div
            val num2Mostrar = DivFragmentArgs.fromBundle(it).num2Div
            textViewResultadoDiv.text = resultado
            textViewDivProceso.text = "$num1Mostrar / $num2Mostrar"
        }
    }

}