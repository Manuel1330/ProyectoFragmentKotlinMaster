package com.example.proyectofragmentkotlin

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.Navigation
import kotlinx.android.synthetic.main.fragment_calculadora_main.*

class CalculadoraMainFragment : Fragment() {
    var resultado = 0.0
    var num1 = 0.0
    var num2 = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_calculadora_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        buttonEnviarCal.setOnClickListener {
            if (editTextNumber1.text.isNullOrEmpty() || editTextNumber2.text.isNullOrEmpty()) {
                Toast.makeText(activity, "Rellena ambos campos", Toast.LENGTH_LONG).show()
            } else {
                num1 = editTextNumber1.text.toString().toDouble()
                num2 = editTextNumber2.text.toString().toDouble()
                if (radioButtonSuma.isChecked) {
                    resultado = num1 + num2
                    val directions = CalculadoraMainFragmentDirections.actionCalculadoraMainFragmentToSumaFragment(resultadoSum = resultado.toString(), Num1Sum = num1.toString(), Num2Sum = num2.toString())
                    Navigation.findNavController(it).navigate(directions)
                } else {
                    if (radioButtonResta.isChecked) {
                        resultado = num1 - num2
                        val directions = CalculadoraMainFragmentDirections.actionCalculadoraMainFragmentToRestaFragment(resultadoResta = resultado.toString(), num1Rest = num1.toString(), num2Rest = num2.toString())
                        Navigation.findNavController(it).navigate(directions)
                    } else {
                        if (radioButtonMulti.isChecked) {
                            resultado = num1 * num2
                            val directions = CalculadoraMainFragmentDirections.actionCalculadoraMainFragmentToMultiFragment(resultadoMulti = resultado.toString(), num1Multi = num1.toString(), num2Multi = num2.toString())
                            Navigation.findNavController(it).navigate(directions)
                        } else {
                            resultado = num1 / num2
                            val directions = CalculadoraMainFragmentDirections.actionCalculadoraMainFragmentToDivFragment(resultadoDiv = resultado.toString(), num1Div = num1.toString(), num2Div = num2.toString())
                            Navigation.findNavController(it).navigate(directions)
                        }
                    }
                }
            }
        }
    }

}